"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const services = [
    {
        id: "global-clients",
        title: "Global Clients",
        subtitle: "Elite Partnerships",
        description: "We partner with ambitious businesses across the UK, EU ,UAE, APAC and USA to build high-performing offshore teams that deliver measurable results across recruitment, marketing, sales, automation, and finance.",
        image: "/assets/hero/recruitment.png",
    },
    {
        id: "recruitment",
        title: "Recruitment Services",
        subtitle: "Elite Partnerships",
        description: "Offshore recruitment specialists who cut time-to-hire by 60%, reduce costs by half, and place right-fit talent across UK, EU, UAE, APAC and USA.",
        image: "/assets/hero/recruitment.png",
    },
    {
        id: "bizdev",
        title: "Business Development",
        subtitle: "Elite Partnerships",
        description: "Structured outreach, smart partnerships, and a consistent sales pipeline that turns reactive businesses into proactive growth engines.",
        image: "/assets/hero/bizdev.png",
    },
    {
        id: "marketing",
        title: "Digital Marketing",
        subtitle: "Elite Partnerships",
        description: "Full-service marketing covering SEO, social media, paid ads, and email all built to grow your brand and convert the right audience into revenue.",
        image: "/assets/hero/marketing.png",
    },
    {
        id: "ai-automation",
        title: "AI & Automation",
        subtitle: "Elite Partnerships",
        description: "From intelligent workflows to process automation, we help businesses eliminate repetitive tasks, reduce human error, and scale operations faster.",
        image: "/assets/services_inner_banner_bg.png",
    },
    {
        id: "finance",
        title: "Accounting & Finance",
        subtitle: "Elite Partnerships",
        description: "Professional bookkeeping, payroll, and tax compliance   real-time financial clarity without the cost of an in-house finance team.",
        image: "/assets/hero/finance.png",
    }
];

export function HeroSectionV8() {
    const [activeIndex, setActiveIndex] = useState(0);

    const nextSlide = useCallback(() => {
        setActiveIndex((prev) => (prev + 1) % services.length);
    }, []);

    useEffect(() => {
        const timer = setInterval(nextSlide, 10000);
        return () => clearInterval(timer);
    }, [nextSlide]);

    return (
        <section id="hero" className="relative min-h-[100dvh] bg-white flex flex-col justify-center pt-32 md:pt-36 lg:pt-44 pb-16 overflow-hidden scroll-mt-32">
            {/* Background with Increased Visibility */}
            <div className="absolute inset-0 z-0">
                <AnimatePresence>
                    <motion.div
                        key={services[activeIndex].id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 0.65 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className="absolute inset-0"
                    >
                        <Image
                            src={services[activeIndex].image}
                            alt=""
                            fill
                            className="object-cover"
                            priority
                        />
                    </motion.div>
                </AnimatePresence>

                {/* Refined Overlays for Image Clarity and Text Contrast */}
                <div className="absolute inset-0 bg-white/30" />
                <div className="absolute inset-0 bg-gradient-to-t from-white via-white/40 to-white/10" />
            </div>

            <div className="container-premium relative z-10 w-full text-center flex-grow flex flex-col justify-center">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={services[activeIndex].id}
                        initial={{ opacity: 0, y: 40 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -30 }}
                        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                        className="max-w-4xl mx-auto"
                    >
                        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-[5.5rem] font-bold text-slate-900 leading-[1.1] mb-6 md:mb-8 tracking-tighter drop-shadow-sm">
                            A Global Engine for <br />
                            <span className="text-secondary">{services[activeIndex].title}</span>
                        </h1>

                        <p className="text-sm sm:text-base md:text-lg lg:text-xl text-slate-700 max-w-2xl lg:max-w-3xl mx-auto mb-10 md:mb-12 leading-relaxed font-normal">
                            {services[activeIndex].description}
                        </p>

                        <div className="flex flex-col items-center justify-center gap-8">
                            <Button asChild size="lg" className="rounded-xl bg-secondary hover:bg-secondary/90 text-white font-bold h-14 px-8 shadow-xl shadow-secondary/20 transition-all border-none">
                                <Link href="/contact" className="flex items-center gap-2 text-[15px] tracking-wide">
                                    GET STARTED NOW
                                    <ArrowRight className="h-5 w-5" />
                                </Link>
                            </Button>

                            {/* Pagination Controls - Now placed after CTA button */}
                            <div className="flex items-center gap-2">
                                {services.map((_, index) => {
                                    const isActive = activeIndex === index;
                                    return (
                                        <button
                                            key={index}
                                            onClick={() => setActiveIndex(index)}
                                            className="relative py-2 px-1 group focus:outline-none"
                                            aria-label={`Go to slide ${index + 1}`}
                                        >
                                            <div
                                                className={`h-2.5 rounded-full transition-all duration-500 ease-in-out ${isActive ? 'w-10 bg-secondary' : 'w-2.5 bg-slate-300 group-hover:bg-slate-400'
                                                    }`}
                                            />
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    </motion.div>
                </AnimatePresence>
            </div>



        </section>
    );
}
