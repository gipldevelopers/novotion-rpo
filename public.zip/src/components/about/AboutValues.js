"use client";

import { motion } from "framer-motion";
import { Zap, ShieldCheck, Users, Target, Sparkles } from "lucide-react";

const values = [
    {
        icon: Zap,
        title: "Adaptability",
        description: "Change is not a challenge—it's our advantage. We pivot in real time, realign without friction, and keep execution moving no matter what shifts.",
        color: "from-orange-500/20 to-orange-500/0"
    },
    {
        icon: ShieldCheck,
        title: "Adherence",
        description: "Every delivery is measured against a defined standard—no shortcuts, no exceptions. Consistency isn't occasional for us; it's the foundation everything is built on.",
        color: "from-secondary/20 to-secondary/0"
    },
    {
        icon: Users,
        title: "Accountability",
        description: "We own every outcome from start to finish—no delays, no excuses, no passing the buck. If it carries our name, it carries our full responsibility.",
        color: "from-slate-500/20 to-slate-500/0"
    },
    {
        icon: Target,
        title: "Accuracy",
        description: "We don't guess—we verify, we validate, and we deliver with precision. Because getting it right the first time isn't a goal, it's a standard.",
        color: "from-secondary/20 to-secondary/0"
    },
    {
        icon: Sparkles,
        title: "Acknowledgement",
        description: "Great results are built by valued people, and we never let effort go unseen. We celebrate every contribution because recognition is what turns performance into culture.",
        color: "from-orange-500/20 to-orange-500/0"
    },
];

export function AboutValues() {
    return (
        <section className="py-20 md:py-32 bg-slate-50 relative overflow-hidden">
            <div className="container-premium relative z-10">
                {/* Section Header */}
                <div className="text-center max-w-3xl mx-auto mb-16 md:mb-20">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-slate-200 text-secondary text-[10px] font-bold uppercase tracking-[0.4em] mb-8 shadow-sm"
                    >
                        <Sparkles className="h-4 w-4" />
                        Our Foundation
                    </motion.div>
 
                    <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6 tracking-tighter font-display">
                        The <span className="text-secondary italic underline underline-offset-8 decoration-secondary/30">5A</span> Core Values.
                    </h2>
  
                    <p className="text-slate-500 text-base md:text-lg font-light leading-relaxed max-w-2xl mx-auto">
                        Our Five A's (5A) aren't just words on a wall; they are the operational standards that drive every decision we make.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {values.map((value, index) => (
                        <motion.div
                            key={value.title}
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6, delay: index * 0.1 }}
                            className="group relative p-8 md:p-10 rounded-[2.5rem] bg-white border border-slate-200 hover:border-secondary/20 transition-all duration-500 shadow-sm hover:shadow-2xl hover:shadow-slate-200/50"
                        >
                            <div className="relative z-10">
                                <div className="mb-8 relative">
                                    <div className={`absolute inset-0 bg-gradient-to-br ${value.color} blur-2xl opacity-0 group-hover:opacity-40 transition-opacity duration-500`} />
                                    <div className="relative w-14 h-14 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 group-hover:text-secondary group-hover:bg-white transition-all shadow-sm">
                                        <value.icon className="h-6 w-6" />
                                    </div>
                                </div>

                                <h3 className="text-xl font-bold text-slate-900 mb-4 tracking-tight group-hover:text-secondary transition-colors font-display">
                                    {value.title}
                                </h3>

                                <p className="text-slate-500 text-[14px] font-light leading-relaxed">
                                    {value.description}
                                </p>
                            </div>

                            {/* Accent Dot */}
                            <div className="absolute top-8 right-8 w-1 h-1 rounded-full bg-slate-200 group-hover:bg-secondary transition-colors" />
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
}

